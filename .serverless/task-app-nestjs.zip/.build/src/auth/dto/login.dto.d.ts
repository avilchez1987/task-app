export declare class LoginDto {
    email: string;
    password: string;
}
