export declare class RegisterDto {
    email: string;
    password: string;
}
