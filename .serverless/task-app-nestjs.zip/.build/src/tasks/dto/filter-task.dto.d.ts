export declare class FilterTaskDto {
    status?: string;
    priority?: string;
    page?: string;
    limit?: string;
}
